Esta carpeta y el contenido de toda ella es la aplicacion ejecutable y funciona de manera independiente del restro del código.
## Aplicación ejecutable para repartir los gastos comunes de una pareja de una manera proporcional al salario de cada uno de los miembros.

# Modo de instalación.

Si lo vas a descargar desde Github (https://github.com/Quikeramos1/Reparto-de-gastos/tree/main/Reparto%20de%20gastos%20),
Los pasos a seguir son lo siguientes:

	1- Descargar archivo comprimido ("Reparto de gastos ejecutable").
	2- Ejecutar el archivo "tk" de la ruta "/dist/tk/tk"

Si tiene el archivo comprimido,
Los pasos a seguir son los siguientes:

	1- Descomprimir el archivo "reparto de gastos.zip"
	2- Ejecutar el archivo "tk" de la ruta "/dist/tk/tk

# Modo de uso.

-En la primera ventana deberás introducir los nombres y salarios de los miembros de la pareja y pulsar "calcular"
-En la siguiente ventana llamada "introducir gastos" deberás ir añadiendo el concepto y el importe del gasto en los campos correspondientes y pulsar el botón "añadir gasto".
 Podrás ver el último gasto añadido en el texto mostrado en pantalla. Una vez que hayas añadido todos los gastos a dividir, pulsar el botón "calcular gastos"
-La aplicación te mostrará como quedaría el reparto de los gastos comunes en función al salario de cada persona de la pareja.